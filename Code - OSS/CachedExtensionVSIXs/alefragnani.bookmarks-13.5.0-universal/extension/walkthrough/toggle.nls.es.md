## Alternar marcadores

Puedes marcar o desmarcar marcadores en cualquier posición. También puedes elegir **etiquetas** para cada marcador.

![Alternar](../images/printscreen-toggle.png)

> Consejo: usa el atajo de teclado <kbd>Cmd</kbd> + <kbd>Alt</kbd> + <kbd>K</kbd>