## Toggle Bookmarks

You can easily Mark/Unmark bookmarks on any position. You can even define **Labels** for each bookmark.

![Toggle](../images/printscreen-toggle.png)

> Tip: Use Keyboard Shortcut <kbd>Cmd</kbd> + <kbd>Alt</kbd> + <kbd>K</kbd>